/* Dummy file  -- Not needed after integration of nemesis library into exodus. */

/* Provided in case an application used to include this file in the past. */
